# @kairos/chat-ui

Official Chat UI component for the Kairós Platform. Reusable across all Kairós apps.

## Installation

```bash
npm install @kairos/chat-ui
# or
yarn add @kairos/chat-ui
# or
pnpm add @kairos/chat-ui
```

## Usage

```tsx
import { KairosChat } from "@kairos/chat-ui"
import "@kairos/chat-ui/styles.css"

function App() {
  return (
    <KairosChat
      config={{
        app: { name: "Kairós Igreja", slug: "igreja" },
        tenant: { name: "Igreja Central", slug: "igreja-central" },
        user: { id: "1", name: "João Silva", email: "joao@igreja.com" },
        model: { name: "GPT-5.5", provider: "OpenRouter" },
        permissions: {
          canUploadImages: true,
          canUploadDocuments: true,
          canUseVoice: true,
          canUseTools: true,
          canAccessHistory: true,
        },
        suggestions: [
          { id: "1", label: "Gerar relatório", prompt: "Gere um relatório mensal", icon: "document" },
          { id: "2", label: "Análise de dados", prompt: "Analise os dados financeiros", icon: "sparkles" },
        ],
        api: {
          baseUrl: process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000",
          apiKey: process.env.NEXT_PUBLIC_API_KEY,
        },
        theme: { mode: "dark" },
      }}
      callbacks={{
        onMessageSend: (msg) => console.log("Sent:", msg),
        onError: (err) => console.error("Error:", err),
        onConnectionChange: (status) => console.log("Connection:", status),
      }}
    />
  )
}
```

## Props

### `KairosChatProps`

| Prop | Type | Description |
|------|------|-------------|
| `config` | `ChatConfig` | Application configuration |
| `callbacks?` | `ChatCallbacks` | Event callbacks |
| `className?` | `string` | Additional CSS class |
| `style?` | `React.CSSProperties` | Inline styles |

### `ChatConfig`

```typescript
interface ChatConfig {
  app: AppInfo         // App name, slug, logo
  tenant: TenantInfo   // Tenant/company name, slug
  user: UserInfo       // Current user info
  model: ModelInfo     // AI model info
  tools?: ToolInfo[]   // Available tools
  suggestions?: SuggestionCard[]  // Quick suggestion cards
  permissions?: Permissions       // Feature permissions
  theme?: ThemeConfig  // Theme customization
  api: ApiConfig       // API endpoints
}
```

## Components

- `KairosChat` - Main component
- `ChatWindow` - Standalone chat window
- `ChatMessage` - Individual message bubble
- `ChatInput` - Message input with attachments and voice
- `Header` - Top bar with app/tenant/user info
- `Sidebar` - Conversation history sidebar
- `AvatarCanvas` - Animated AI avatar (canvas 2D)
- `StreamingMessage` - Streaming message with cursor
- `ToolIndicator` - Running tools indicator
- `SuggestionCards` - Quick action suggestions

## Hooks

```typescript
import { useChatStore, useConfigStore } from "@kairos/chat-ui"
```

- `useChatStore` - Messages, conversations, streaming state
- `useConfigStore` - App configuration and theme

## Theming

The component supports dark mode, light mode, and system mode. Customize via `ThemeConfig`:

```typescript
{
  theme: {
    mode: "dark", // "light" | "dark" | "system"
    primaryColor: "#1e40af",
    accentColor: "#7c3aed",
  }
}
```

For advanced customization, override CSS variables:

```css
:root {
  --kairos-primary: #your-color;
  --kairos-radius: 8px;
}
```

## Architecture

```
@kairos/chat-ui
├── KairosChat (main export)
│   └── ChatWindow
│       ├── Header (app/tenant/user/model/status)
│       ├── Sidebar (conversation history)
│       ├── Messages area
│       │   ├── ChatMessage[]
│       │   ├── StreamingMessage
│       │   └── ToolIndicator
│       ├── Empty state
│       │   ├── AvatarCanvas
│       │   ├── Capability badges
│       │   └── SuggestionCards
│       └── ChatInput
│           ├── Voice button (MediaRecorder)
│           ├── File upload (images, PDFs, Office)
│           └── Send button
└── Stores (Zustand)
    ├── chatStore
    └── configStore
```

## License

MIT
